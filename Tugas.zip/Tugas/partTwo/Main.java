package Tugas.partTwo;

// * Looking downward from this deadly height and never realizing why I fight... ~ lirik lagu

public class Main {
    public static void main(String[] args) {

        DataPemilih data = new DataPemilih();
        data.Menu();

    }
}
